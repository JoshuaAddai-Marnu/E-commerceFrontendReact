// src/App.js
import React from 'react';
import Students from './components/Students';

function App() {
  return (
    <div className="App">
      <Students />
    </div>
  );
}

export default App;
