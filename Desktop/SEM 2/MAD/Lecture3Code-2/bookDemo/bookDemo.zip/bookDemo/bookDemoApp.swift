//
//  bookDemoApp.swift
//  bookDemo
//
//  Created by Girish Lukka on 08/03/2022.
//

import SwiftUI

@main
struct bookDemoApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
            //ContentView()
            //ContentView1()
            //ContentView2()
            //ContentView3()
           // ContentView4()
        }
    }
}
