//
//  ContentView.swift
//  Financial calculator
//
//  Created by Joshua Addai-Marnu on 22/03/2024.
//

import SwiftUI

struct ContentView: View {
    @AppStorage("AR") var AR: String = ""
    @AppStorage("A") var A: String = ""
    @AppStorage("Y") var Y: String = ""
    @State private var PI: Double = 0.0
    @State var solver = Solver()
    var body: some View {
        ScrollView {
            
            VStack {
                Text("Financial calculator")
                    .font(.title)
                    .padding()
                Label("Enter Annual Rate", systemImage: "r.circle.fill")
                    .font(.title)
                    .padding()
                TextField("AR eg: 1.0", text: $AR)
                    .keyboardType(.decimalPad)
                    .padding()
                    .border(Color.black)
                    .multilineTextAlignment(.center)
                Label("Enter Amounts", systemImage: "a.circle.fill")
                    .font(.title)
                    .padding()
                TextField("A eg: 1.0", text: $A)
                    .keyboardType(.decimalPad)
                    .padding()
                    .border(Color.black)
                    .multilineTextAlignment(.center)
                Label("Enter number of Years", systemImage: "y.circle.fill")
                    .font(.title)
                    .padding()
                TextField("Y eg: 1.0", text: $Y)
                    .keyboardType(.decimalPad)
                    .padding()
                    .border(Color.black)
                    .multilineTextAlignment(.center)

                Button("Solve for Principal Investment") {
                    solver.solveForPInvestment(AR: AR, A: A, Y: Y)
                    PI = solver.PI
                }
                .disabled(AR.isEmpty || A.isEmpty || Y.isEmpty)
                .padding()
                Text("Principal Investment: \(String(format: "%.2f", PI))")

                   }
                   .padding()
        }
        .background(Image("chelsea-wallpaper-8468-p").resizable().scaledToFill().opacity(0.3))
        
       
    }
//    func solveForPInvestment(){
//        if let ARV = Double(AR), let AV = Double(A), let NoY = Double(Y){
//            let MR = pow( (1 + (ARV/100)), (1/12)) - 1
//            PI = AV / pow((1 + MR), (NoY * 12))
//        }
//    }
//    func solveForPInvestment(){
//        if let ARV = Double(AR), let AV = Double(A), let NoY = Double(Y){
//            let MR = pow((1+(ARV/100)),1/12) - 1
//            PI = AV / pow((1 + MR), NoY * 12)
//        }
//    }
//    func solveForPInvestment(){
//        if let ARV = Double(AR), let AV = Double(A), let NoY = Double(Y){
//            let MR = pow((1 + ARV/100),(1/12)) - 1
//            PI = AV / pow((1 + MR), (NoY * 12))
//        }
//    }
    func solveForPInvestmment(){
        if let ARV = Double(AR), let AV = Double(A), let NoY = Double(Y){
            let MR = pow((1 + ARV/100), (1/12)) - 1
            PI = AV / pow((1 + MR), (NoY * 12))
        }
    }
}


#Preview {
    ContentView()
}
