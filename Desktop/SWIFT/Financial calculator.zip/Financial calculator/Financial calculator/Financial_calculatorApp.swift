//
//  Financial_calculatorApp.swift
//  Financial calculator
//
//  Created by Joshua Addai-Marnu on 22/03/2024.
//

import SwiftUI

@main
struct Financial_calculatorApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
