//
//  Solver.swift
//  Financial calculator
//
//  Created by Joshua Addai-Marnu on 22/03/2024.
//

import Foundation
class Solver{
    //var AR: Double = 0.0
    //var A: Double = 0.0
   //var Y: Double = 0.0
    var PI: Double = 0.0
    func solveForPInvestment(AR: String, A: String, Y: String){
        if let ARV = Double(AR), let AV = Double(A), let NoY = Double(Y){
            let MR = pow((1 + ARV/100),(1/12)) - 1
            PI = AV / pow((1 + MR), (NoY * 12))
        }
        //return(PI)
    }
}
